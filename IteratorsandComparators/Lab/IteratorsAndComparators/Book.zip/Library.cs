﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace IteratorsAndComparators
{
    public class Library : IEnumerable<Book>
    {
        private List<Book> books;

        public Library(params Book[] books)
        {
            this.books = books.ToList();
        }

        public IEnumerator<Book> GetEnumerator()
        {
            return new LibraryIterator(books);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    class LibraryIterator : IEnumerator<Book>
    {
        private List<Book> books;
        private int currentIndex;

        public LibraryIterator(List<Book> books)
        {
            this.books = books;
            this.books.Sort(new BookComparator());
            this.currentIndex = -1;
        }

        public void Dispose(){}

        public bool MoveNext()
        {
            return ++currentIndex < books.Count;
        }
        public void Reset(){}

        public Book Current
        {
            get { return books[currentIndex];  }
        }
        object IEnumerator.Current => Current;
    }
}
